using Plots 
using DifferentialEquations

s = 19.5
fi = 3 * π / 4
dr(r, p, tetha) = r / sqrt(23.01)
x = (s*10)/59
r = x
tetha = -pi
tethaRange = (tetha + 2*pi, tetha)

problem = ODEProblem(dr, r, tethaRange)
solution = solve(problem, Tsit5(), reltol=1e-8, abstol=1e-8)
solution.u[1]

gr()
plot!(solution.t[1:21], solution.u[1:21], proj = :polar, line = (:green, 2), label = "Лодка браконьеров")
plot!([fi, fi+0.000001], [0,10], line = (:red, 1), label = "Катер береговой охраны", legend = :bottomright)

savefig("test2.png")